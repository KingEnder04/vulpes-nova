package vulpesnova.VNContent.VNArmors.VNWoodSet;

import necesse.inventory.item.armorItem.ChestArmorItem;

public class WoodenChestplate extends ChestArmorItem {

    public WoodenChestplate() {
        super(6, 200, Rarity.NORMAL, "woodenchestplatevn", "woodenarmsvn");
    }

}
