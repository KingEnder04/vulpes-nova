package vulpesnova.VNContent;

import necesse.level.gameObject.SaplingObject;

public class BlockberrySaplingObjectVN extends SaplingObject {

    public BlockberrySaplingObjectVN(String textureName, String resultObjectStringID, int minGrowTimeInSeconds, int maxGrowTimeInSeconds, boolean addAnySaplingIngredient, String... validTiles) {
        super(textureName, resultObjectStringID, minGrowTimeInSeconds, maxGrowTimeInSeconds, addAnySaplingIngredient, validTiles);
    }

}
