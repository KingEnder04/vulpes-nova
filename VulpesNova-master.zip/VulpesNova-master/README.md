Vulpes Nova for Necesse.

Check out the [modding wiki page](https://necessewiki.com/Modding) for more.